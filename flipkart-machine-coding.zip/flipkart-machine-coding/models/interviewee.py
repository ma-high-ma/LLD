class Interviewee:
    def __init__(self, id, name, available_slots, status):
        self.id = id
        self.name = name
        self.available_slots = available_slots
        self.status = status
