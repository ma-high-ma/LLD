class Interviewer:
    def __init__(self, id, name, types, experience, available_slots, status):
        self.id = id
        self.name = name
        self.types = types
        self.experience = experience
        self.available_slots = available_slots
        self.status = status
